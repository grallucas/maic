import numpy as np
import tensorflow as tf
import pickle

# Data from https://www.cs.toronto.edu/~kriz/cifar.html

def get_categegory_names():
    with open('/data/ai_club/util/datasets/CIFAR-10/cifar-10-batches-py/batches.meta', 'rb') as f:
        names = [str(s)[2:-1] for s in pickle.load(f, encoding='bytes')[b'label_names']]
        return names, len(names)
    
def get_data(max_batch=1):
    def get_file_data(fname):
        with open(fname, 'rb') as f:
            imgs_dict = pickle.load(f, encoding='bytes')
            imgs = imgs_dict[b'data']
            imgs = np.array([
                np.reshape(np.vstack((img[0:1024], img[1024:2048], img[2048:3072])).T.ravel(), (32,32,3))
                for img in imgs
            ]) / 255.0
            img_labels = np.array(imgs_dict[b'labels'])
        return imgs, img_labels
    
    imgs = []
    img_labels = []

    for i in range(1,max_batch+1): # load files 1 thru max_batch
        imgs_i, img_labels_i = get_file_data(f'/data/ai_club/util/datasets/CIFAR-10/cifar-10-batches-py/data_batch_{i}')
        imgs += [imgs_i]
        img_labels += [img_labels_i]
        
    return np.concatenate(imgs), np.concatenate(img_labels)

# import tensorflow_hub as hub # IMPORT HERE so other things don't break
# upscale_model = upscale_model = hub.load('https://tfhub.dev/captain-pool/esrgan-tf2/1')
# def show_upscaled(img_data):
#     hr_image = np.copy(img_data)

#     hr_image = tf.expand_dims(hr_image, 0)
#     hr_image = tf.cast(hr_image, tf.float32)

#     img_up = upscale_model(upscale_model(255*hr_image)) #upscale twice
#     img_up = tf.cast(tf.clip_by_value(img_up, 0, 255), tf.uint8)

#     plt.figure(figsize = (30,4))
#     plt.imshow(img_up[0], interpolation='bicubic')