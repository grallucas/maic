from copy import deepcopy
import numpy as np
import time
import gui

class TicTacToeEnv():
    def __init__(self, render=False, wait=0, player=1):
        self.player = player
        self.render = render
        self.wait = wait
        if self.render:
            self.root, self.canvas = gui.initialize_window()
        actions = np.zeros((9,3,3))
        action_idx = 0
        for i in range(3):
            for j in range(3):
                actions[action_idx,i,j] = 1
                action_idx+=1
        self.actions = actions

    def reset(self):
        self.board = np.zeros((3,3))
        self.turn = 1
        if self.render:
            gui.draw_board(self.canvas, self.root, self.board)
        if self.player == 2:
            usable_actions = []
            for i, action in enumerate(self.actions):
                if self.check_action_usable(action):
                    usable_actions.append(i)
            action = deepcopy(self.actions[np.random.choice(usable_actions)])
            action *= self.turn
            self.board = self.board.astype(int) | action.astype(int)

            time.sleep(self.wait)
            if self.render:
                gui.draw_board(self.canvas, self.root, self.board)

            self.turn = 2
        return self.board, 0, False, self.turn

    def step(self, _action):
        action = deepcopy(_action)
        if not self.check_action_usable(action):
            return self.board, -1, False, self.turn

        action *= self.turn
        self.board = self.board.astype(int) | action.astype(int)
        time.sleep(self.wait)
        if self.render:
            gui.draw_board(self.canvas, self.root, self.board)

        if self._check_player_won():
            return self.board, 1, True, self.turn
        elif self._check_tie():
            return self.board, 0, True, self.turn

        if self.turn == 1:
            self.turn = 2
        else:
            self.turn = 1

        usable_actions = []
        for i, action in enumerate(self.actions):
            if self.check_action_usable(action):
                usable_actions.append(i)
        action = deepcopy(self.actions[np.random.choice(usable_actions)])
        action *= self.turn
        self.board = self.board.astype(int) | action.astype(int)

        time.sleep(self.wait)
        if self.render:
            gui.draw_board(self.canvas, self.root, self.board)

        if self._check_player_won():
            return self.board, 0, True, self.turn
        elif self._check_tie():
            return self.board, 0, True, self.turn
        if self.turn == 1:
            self.turn = 2
        else:
            self.turn = 1

        return self.board, 0, False, self.turn

    def check_action_usable(self, action):
        try:
            idx = np.where(action == 1)
            idx = (idx[0][0], idx[1][0])
            return self.board[idx] == 0
        except:
            print(self.actions)

    def _check_player_won(self):
        for row in self.board:
            if np.all(row == self.turn):
                return True
        for col in self.board.T:
            if np.all(col == self.turn):
                return True
        if np.all(np.array([self.board[0,0], self.board[1,1], self.board[2,2]]) == self.turn) or np.all(np.array([self.board[0,2], self.board[1,1], self.board[2,0]]) == self.turn):
            return True
        return False

    def _check_tie(self):
        # Big assumption that this is only called after _check_player_won
        unique, counts = np.unique(self.board, return_counts=True)
        if 0 not in unique:
            return True
        return False

    def close(self):
        if self.render:
            self.root.destroy()
