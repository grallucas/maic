import tkinter as tk

board_pixel_width = 1080
padding = 40
line_width = 10

def initialize_window():
    root = tk.Tk()
    root.title("Tic Tac Toe!")
    root.geometry(f"{int(board_pixel_width+padding*2)}x{board_pixel_width+padding*2}")
    canvas = tk.Canvas(root, width=int(board_pixel_width+padding*2), height=board_pixel_width+padding*2)
    canvas.pack()
    return root, canvas

def draw_board(
        canvas: tk.Canvas, 
        root: tk.Tk,
        board):
    canvas.delete('all')
    # draw the grid
    canvas.create_line(padding, padding+board_pixel_width/3, board_pixel_width, padding+board_pixel_width/3, fill='black', width=line_width)
    canvas.create_line(padding, padding+2*board_pixel_width/3, board_pixel_width, padding+2*board_pixel_width/3, fill='black', width=line_width)
    canvas.create_line(padding+board_pixel_width/3, padding, padding+board_pixel_width/3, board_pixel_width, fill='black', width=line_width)
    canvas.create_line(padding+2*board_pixel_width/3, padding, padding+2*board_pixel_width/3, board_pixel_width, fill='black', width=line_width)
    
    for i in range(board.shape[0]):
        for j in range(board.shape[1]):
            if board[i,j] == 1:
                draw_x(canvas, i, j)
            elif board[i,j] == 2:
                draw_o(canvas, i, j)
    
    root.update()

def draw_x(canvas, i, j):
    canvas.create_line(
        padding+i*board_pixel_width/3,
        padding+j*board_pixel_width/3,
        padding+(i+1)*board_pixel_width/3,
        padding+(j+1)*board_pixel_width/3,
        fill='black', width=line_width
        )
    canvas.create_line(
        padding+i*board_pixel_width/3,
        padding+(j+1)*board_pixel_width/3,
        padding+(i+1)*board_pixel_width/3,
        padding+j*board_pixel_width/3,
        fill='black', width=line_width
        )

def draw_o(canvas,i,j):
    canvas.create_oval(
        padding+i*board_pixel_width/3,
        padding+j*board_pixel_width/3,
        padding+(i+1)*board_pixel_width/3,
        padding+(j+1)*board_pixel_width/3,
        outline='black', width=line_width
        )
